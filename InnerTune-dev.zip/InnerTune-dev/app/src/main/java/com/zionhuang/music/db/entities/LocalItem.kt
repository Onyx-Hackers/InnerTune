package com.zionhuang.music.db.entities

sealed class LocalItem {
    abstract val id: String
}