package com.zionhuang.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class Icon(
    val iconType: String,
)